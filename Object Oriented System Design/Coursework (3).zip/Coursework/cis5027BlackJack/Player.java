/**
 * Implementation of the Player Class
 * 
 * @author St20155999
 * 
 */
package cis5027BlackJack;

public class Player {
	//Add Player
	public class AddPlayer {
		private String name;
			
		//Set and get Player Name
		public void Player(String name, int position){		
			this.setName(name);
			
			}
			
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		
	}

	public Player(String pName, int i) {
		// Constructor for Player
	}

	public static void add(Player newPlayer) {
		// Add New Player
	}

}
