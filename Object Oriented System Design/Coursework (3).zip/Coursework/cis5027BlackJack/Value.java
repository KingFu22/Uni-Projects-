package cis5027BlackJack;
/**
 * An enum representing the  possible Values of the card.
 * 
 * @author St20155999
 * 
 */


public enum Value {
	  TWO, 
	  THREE, 
	  FOUR, 
	  FIVE, 
	  SIX, 
	  SEVEN, 
	  EIGHT, 
	  NINE, 
	  TEN, 
	  JACK, 
	  QUEEN, 
	  KING, 
	  ACE
}
